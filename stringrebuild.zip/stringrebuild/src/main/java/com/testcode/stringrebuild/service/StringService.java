package com.testcode.stringrebuild.service;

import com.testcode.stringrebuild.enums.ActionTypeEnum;

public interface StringService {
    void stringUtil(String str, ActionTypeEnum actionType);
}
