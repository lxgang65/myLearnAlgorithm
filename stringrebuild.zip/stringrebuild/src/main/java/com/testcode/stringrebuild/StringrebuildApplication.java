package com.testcode.stringrebuild;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StringrebuildApplication {

    public static void main(String[] args) {
        SpringApplication.run(StringrebuildApplication.class, args);
    }

}
