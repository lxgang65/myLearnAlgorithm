package com.testcode.stringrebuild.service;

public interface IStringService {
    String stringReplace(String str);

    String StringReplaceWithPrevWord(String str);


}
