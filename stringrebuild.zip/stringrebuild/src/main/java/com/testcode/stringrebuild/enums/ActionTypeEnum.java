package com.testcode.stringrebuild.enums;

public enum ActionTypeEnum {
    REPLACE_EMPTY, REPLACE_WORD
}
